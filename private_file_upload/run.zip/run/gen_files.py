# pf-001 -> pf-009
table = {
    'a': 52428801,
    'aa': 52428801,
    'a' * 255: 52428801,
    'b' * 254: 52428801,
    'c' * 128: 1,
    'd' * 128: 2,
    'e' * 128: 104857600,
    'f' * 128: 104857599,
    'g' * 128: 52428801,
}
for filename, size in table.items():
    content = 'a' * size
    open(filename, "w").write(content)


# pf010 - pf017
for i in range(10, 18):
    filename = f"pf0{i}.txt"
    if i == 10:
        # invalid file
        open(filename, "w").write("")
    else:
        open(filename, "w").write("this is valid file.")
    
# pf018 - pf026
table = {
    18: 10,
    19: 105906176, # 101MB
    20: 0,
    21: 10,
    22: 105906176,
    23: 0,
    24: 10,
    25: 105906176,
    26: 0,
}
for i in range(18, 27):
    filename = f"pf0{i}.txt"
    open(filename, "w").write('a' * table[i])

# pf027 - pf029
open("duplicated.txt", "w").write("This file is duplicated")